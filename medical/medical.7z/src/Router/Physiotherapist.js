import React from 'react'

export default function Physiotherapist() {
    return (
        <div>
            <h1>Hi Physiotherapist</h1>
        </div>
    )
}
