import React from 'react'

export default function Hearse() {
    return (
        <div>
            HI Hearse
        </div>
    )
}
