import React from 'react'

export default function OxygenCylinder() {
    return (
        <div>
            <h1>OxygenCylinder</h1>
        </div>
    )
}
