import React from 'react'

export default function Ambulance() {
    return (
        <div>
            <h1>Ambulance</h1>
        </div>
    )
}
