import React from 'react'

export default function Wheelchair() {
    return (
        <div>
            <h1>Wheelchair</h1>
        </div>
    )
}
