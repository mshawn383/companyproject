import React from 'react'

export default function PaceMaker() {
    return (
        <div>
            <h1>PaceMaker</h1>
        </div>
    )
}
