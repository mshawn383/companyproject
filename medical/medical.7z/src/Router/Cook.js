import React from 'react'

export default function Cook() {
    return (
        <div>
            <h1>Cook</h1>
        </div>
    )
}
